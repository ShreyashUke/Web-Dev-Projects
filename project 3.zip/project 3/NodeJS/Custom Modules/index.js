

// const average = require("./mod");
//  console.log(average([3,4]))
const mod = require("./mod");
 console.log(mod.avg([3,4]))
console.log("this is index");
  