const express = require("express");
const path = require("path");
const app = express();
const port = 80;

//For serving Static Files
app.use("/static", express.static("static"));

//set template engine as pug
app.set("view engine", "pug");

//set the views directory
app.set("views", path.join(__dirname, "views"));

//pug demo endpoint
app.get("/demo", (req, res) => {
  res.status(200).render("demo", { title: "Hey Harry", message: "  Hello there! How are You!!!" });
});

app.get("/", (req, res) => {
  res.status(200).send("this is homepage of my first express app with harry");
});

app.get("/about", (req, res) => {
  res.send("this is about page my first express app with harry");
});

app.post("/about", (req, res) => {
  res.send("this is post request about page my first express app with harry");
});

app.post("/this", (req, res) => {
  res.status(404).send("THis page is not found");
});

app.listen(port, () => {
  console.log(`The application started succesfully on port ${port}`);
});
