// Import the mongoose module
const mongoose = require("mongoose");

// Set up default mongoose connection
const mongoDB = "mongodb://127.0.0.1/shreyasKart";
mongoose.connect(mongoDB, { useNewUrlParser: true, useUnifiedTopology: true });

var db = mongoose.connection;
db.on('error',console.error.bind(console,'connection error:'));

// db.once('open',function(){
//     //We are connected
//     console.log("We are connected bro/sis");
// });



const kittySchema = new mongoose.Schema({
    name: String
  });

  kittySchema.methods.speak = function speak() {
    const greeting = "My name is " + this.name
    console.log(greeting);
  };

  const Kitten = mongoose.model('harryKitty', kittySchema);

  const harryKitty = new Kitten({ name: 'harryKitty' });
  const harryKitty2 = new Kitten({ name: 'harryKitty2' });
// console.log(silence.name); // 'Silence'

// silence.speak();
harryKitty.save(function(err,harryKitty){
    if (err) return console.error(err);
    // harryKitty.speak();
});
harryKitty2.save(function(err,k){
    if (err) return console.error(err);
    // k.speak();
});

Kitten.find({ name: 'harryKitty2' },function(err,kittens){
    if (err) return console.error(err);
console.log(kittens);
});